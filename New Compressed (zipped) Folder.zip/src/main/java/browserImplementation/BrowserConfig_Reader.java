package browserImplementation;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

import configReader.ConfigReader;

public class BrowserConfig_Reader {
	
	WebDriver driver;
	ConfigReader cr;
	
	
	public BrowserConfig_Reader(WebDriver driver)
	{
		this.driver=driver;
	}
  
	
	
	public WebDriver get_chrome(ChromeOptions options)
	{
		
		 driver=new ChromeDriver(options);
		 return driver;
	}
	
	public WebDriver get_Edge()
	{
		 driver=new EdgeDriver();
		 return driver;
		
	}
	
	public void Launch_Url()
	{
		
		try
		{
		cr= new ConfigReader();
		driver.get(cr.get_Url());
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public void Close_Browser()
	{
		driver.quit();
	}

}
