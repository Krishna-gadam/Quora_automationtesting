package pages;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import browserImplementation.BrowserConfig_Reader;
import configReader.ConfigReader;

public class Landingpage {

    ConfigReader cr;
    WebDriver driver;
	BrowserConfig_Reader br;

   public Landingpage(WebDriver driver)
   {
	   
	   this.driver=driver;
   }
	
	public void Sign_In() throws IOException, InterruptedException
	{
		
		br=new BrowserConfig_Reader(driver);
		
	   
	    cr=new ConfigReader();
		WebElement searchbox=driver.findElement(By.xpath(cr.get_InitialSearch()));
		searchbox.sendKeys("Testing");
		searchbox.sendKeys(Keys.ENTER);
		System.out.println("Opened Application...");
		driver.findElement(By.cssSelector(cr.get_IdofEmail())).sendKeys(cr.get_CorrectEmail());
		WebElement password= driver.findElement(By.cssSelector(cr.get_IdofPassword()));	
		password.sendKeys(cr.get_correctPassword());
		Thread.sleep(2000);
		driver.findElement(By.xpath(cr.get_InitialLoginbutton())).click();
		Thread.sleep(5000); 
		System.out.print("sign in succesful");
		
	}
	
	public String Text() throws InterruptedException
	{
		WebElement Insearch= driver.findElement(By.xpath(cr.get_search()));
		Insearch.sendKeys(cr.get_Content());
		Insearch.sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		WebElement result= driver.findElement(By.xpath(cr.get_ResultText()));
		String ACtext= result.getText();
	    return ACtext;
		
	}
	
	public void Logout() throws InterruptedException
	{
		 driver.findElement(By.xpath(cr.get_Nametag())).click();
		 Thread.sleep(3000);
		 WebElement logout= driver.findElement(By.xpath(cr.get_Logout()));
		 logout.click();
		 Thread.sleep(3000);
	}
	
	public WebElement get_Loginbutton()
	{
		
	 WebElement checklogin=driver.findElement(By.xpath(cr.get_CheckLoginButton()));
	 return checklogin;
	 
	 
	}
	
	public boolean checkEmailText() throws InterruptedException, IOException
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement signupButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
		    By.xpath(cr.get_signupEmailButton())));
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", signupButton);
//		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signupButton);


		 driver.findElement(By.name(cr.get_Nameattforsignup())).sendKeys(cr.get_Signupnamecontent());
		 driver.findElement(By.xpath(cr.get_SecondEmail())).sendKeys(cr.get_Incorrect_email());
		 Thread.sleep(5000);
		 File src= ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		 File dest= new File("C:\\Users\\2478571\\eclipse-workspace\\Interim_project\\screenshot\\link.png");
		 dest.getParentFile().mkdirs();
		 FileUtils.copyFile(src,dest);
		 return true;

	}
	
	
	
	
	
	
	
	
	

}
