package Tests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import browserImplementation.BrowserConfig_Reader;
import configReader.ConfigReader;
import pages.Landingpage;

public class Testingpage {
	WebDriver driver;
	BrowserConfig_Reader br;
	Landingpage lp;
	ConfigReader cr;
	
	
	@BeforeTest
public void Browser_Launch() throws InterruptedException
{
		br=new BrowserConfig_Reader(driver);
		
		
		ChromeOptions options;
		options=new ChromeOptions();
		options.addArguments("--disable-blink-features=AutomationControlled");
		driver=br.get_chrome(options);
		br.Launch_Url();
		Thread.sleep(20000);
		lp=new Landingpage(driver);
				
}

	@Test 
public void Check_Text() throws IOException, InterruptedException
{
	Thread.sleep(10000);
	cr=new ConfigReader();
	
	lp.Sign_In();
	Thread.sleep(4000);
    String ACtext=lp.Text();
    String EXtext=cr.get_Expectedcontent();
	Assert.assertEquals(ACtext, EXtext, "Title does not match!");
	System.out.println("Text verified");
	Reporter.log("Check text-passed");
}

	@Test (dependsOnMethods = "Check_Text()")
public void Check_SignupButtonEnabled() throws InterruptedException
{
	lp.Logout();
	Thread.sleep(5000);
	WebElement checkLoginButton=lp.get_Loginbutton();
	Assert.assertFalse(checkLoginButton.isEnabled(), "Sign Up button should be disabled");
	Reporter.log("Login Button verified");
	System.out.println("login button verified");
	
}

@Test (dependsOnMethods="Check_SignupButtonEnabled()")
public 	void CheckTextforInvalidEmail() throws InterruptedException, IOException
{
	lp.checkEmailText();
	Assert.assertFalse(lp.checkEmailText(), "Incorrect Email text not verified");
	System.out.println("Email text verified");
	Reporter.log("Filling Incorrect Email,then obtained the Result text- passed");
	
}

//@AfterMethod
//public void  Browser_close()
//{
//	br.Close_Browser();
//	
//}
	
	
}
